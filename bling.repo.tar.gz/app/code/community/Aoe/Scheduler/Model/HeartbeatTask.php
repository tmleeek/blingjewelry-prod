<?php

class Aoe_Scheduler_Model_HeartbeatTask {

	public function run() {
		return true;
	}

}