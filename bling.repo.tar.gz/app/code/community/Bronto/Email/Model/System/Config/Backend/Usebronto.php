<?php

/**
 * @package   Bronto\Email
 * @copyright 2011-2012 Bronto Software, Inc.
 */
class Bronto_Email_Model_System_Config_Backend_Usebronto extends Mage_Core_Model_Config_Data
{

    protected $_eventPrefix = 'bronto_email_usebronto';

}
