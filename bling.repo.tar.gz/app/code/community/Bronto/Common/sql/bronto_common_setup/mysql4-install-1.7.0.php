<?php

$installer = $this;
/* @var $installer Bronto_Common_Model_Resource_Setup */

$installer->startSetup();

$installer->handleOld();

$installer->endSetup();