<?php

class Bronto_News_Block_Adminhtml_System_Config_About extends Bronto_Common_Block_Adminhtml_System_Config_About
{

    /**
     * @var string
     */
    protected $_module = 'bronto_news';

    /**
     * @var string
     */
    protected $_name = 'Bronto News for Magento';
}
